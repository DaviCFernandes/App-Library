// temporary workaround for expo 45 bug:
// https://github.com/expo/snack/pull/292
// fix: https://github.com/wcandillon/react-native-redash/issues/395#issuecomment-839586492
global.__reanimatedWorkletInit = function () {}
//https://github.com/expo/expo/issues/17758

export default {}